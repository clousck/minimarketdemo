package minimarketdemoFactEJB.model.eventos.managers;

import java.util.List;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import minimarketdemoFactEJB.VwEvento;

/**
 * Session Bean implementation class ManagerEventos
 */
@Stateless
@LocalBean
public class ManagerEventos {

	@PersistenceContext
	private EntityManager em;
    /**
     * Default constructor. 
     */
    public ManagerEventos() {
        // TODO Auto-generated constructor stub
    }

    public List<VwEvento> findAllEventos(){
    	Query q;
    	List listado;
    	String sentenciaJPQL;
    	
    	sentenciaJPQL = "SELECT o FROM VwEvento o";
    	
    	q=em.createQuery(sentenciaJPQL);
    	listado=q.getResultList();
    	
    	return listado;
    }
}
